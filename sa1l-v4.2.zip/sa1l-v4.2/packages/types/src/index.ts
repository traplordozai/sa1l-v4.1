// Consolidate common types and ensure they're properly exported
import { initTRPC } from "@trpc/server"
import { z } from "zod"
import type { inferRouterInputs, inferRouterOutputs } from "@trpc/server"
import type { CreateNextContextOptions } from "@trpc/server/adapters/next"

// User types
export const userSchema = z.object({
  id: z.string(),
  name: z.string().optional(),
  email: z.string().email(),
  role: z.enum(["user", "admin", "faculty"]),
  status: z.enum(["active", "suspended"]),
})

export type User = z.infer<typeof userSchema>

// Session types
export interface Session {
  user: {
    id: string
    email: string
    role: string
  }
  id: string
  lastRotated: number
}

// Context types
export interface Context {
  prisma: any // This should be typed with PrismaClient when available
  session: Session | null
  user: User | null
  req: CreateNextContextOptions["req"]
  res: CreateNextContextOptions["res"]
  previousData: unknown
}

// Input/Output schemas
export const userInput = {
  create: userSchema.omit({ id: true }),
  update: userSchema.partial().extend({ id: z.string() }),
  delete: z.string(),
  resetPassword: z.string(),
  impersonate: z.string(),
}

export const userOutput = {
  getAll: z.array(userSchema),
  create: userSchema,
  update: userSchema,
  delete: userSchema,
  resetPassword: z.object({ success: z.boolean() }),
  impersonate: z.object({
    token: z.string(),
    expiresAt: z.date(),
    impersonatedUser: userSchema.pick({
      id: true,
      email: true,
      name: true,
      role: true,
    }),
  }),
}

// Role types
export const roleSchema = z.object({
  id: z.string(),
  name: z.string(),
  permissions: z.array(z.string()),
})

export type Role = z.infer<typeof roleSchema>

export const roleInput = {
  create: roleSchema.omit({ id: true }),
  update: roleSchema.extend({
    id: z.string(),
  }),
  delete: z.string(),
}

export const roleOutput = {
  getAll: z.array(roleSchema),
  create: roleSchema,
  update: roleSchema,
  delete: roleSchema,
}

// Analytics types
export const analyticsOutput = {
  visitsByPath: z.array(
    z.object({
      path: z.string(),
      _count: z.number(),
    }),
  ),
}

// Create a dummy router type for type inference
const t = initTRPC.context<Context>().create()

export const appRouter = t.router({
  user: t.router({
    getAll: t.procedure.output(userOutput.getAll).query(() => Promise.resolve([])),
    create: t.procedure
      .input(userInput.create)
      .output(userOutput.create)
      .mutation(() => Promise.resolve({} as User)),
    update: t.procedure
      .input(userInput.update)
      .output(userOutput.update)
      .mutation(() => Promise.resolve({} as User)),
    delete: t.procedure
      .input(userInput.delete)
      .output(userOutput.delete)
      .mutation(() => Promise.resolve({} as User)),
    resetPassword: t.procedure
      .input(userInput.resetPassword)
      .output(userOutput.resetPassword)
      .mutation(() => Promise.resolve({ success: true })),
    impersonate: t.procedure
      .input(userInput.impersonate)
      .output(userOutput.impersonate)
      .mutation(() =>
        Promise.resolve({
          token: "",
          expiresAt: new Date(),
          impersonatedUser: {
            id: "",
            email: "",
            name: "",
            role: "user",
          },
        }),
      ),
  }),
  role: t.router({
    getAll: t.procedure.output(roleOutput.getAll).query(() => Promise.resolve([])),
    create: t.procedure
      .input(roleInput.create)
      .output(roleOutput.create)
      .mutation(() => Promise.resolve({} as Role)),
    update: t.procedure
      .input(roleInput.update)
      .output(roleOutput.update)
      .mutation(() => Promise.resolve({} as Role)),
    delete: t.procedure
      .input(roleInput.delete)
      .output(roleOutput.delete)
      .mutation(() => Promise.resolve({} as Role)),
  }),
  analytics: t.router({
    visitsByPath: t.procedure
      .output(analyticsOutput.visitsByPath)
      .query(() => Promise.resolve([] as Array<{ path: string; _count: number }>)),
  }),
})

export type AppRouter = typeof appRouter
export type RouterInput = inferRouterInputs<AppRouter>
export type RouterOutput = inferRouterOutputs<AppRouter>

