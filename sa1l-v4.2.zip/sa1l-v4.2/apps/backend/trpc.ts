import { initTRPC, TRPCError } from "@trpc/server"
import type { CreateNextContextOptions } from "@trpc/server/adapters/next"
import jwt from "jsonwebtoken"
import { z } from "zod"
import { prisma } from "../../../archive13628-pm/apps/backend/db/prisma"
import type { User } from "@/packages/types"

// Define the user type that will be added to the context
export const userSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  name: z.string().optional(),
  role: z.enum(["user", "admin", "faculty"]),
  isImpersonating: z.boolean().optional(),
  originalUser: z
    .object({
      id: z.string(),
      email: z.string().email(),
    })
    .optional(),
})

// Create context based on the request
export async function createContext({ req, res }: CreateNextContextOptions) {
  let user: User | null = null

  // Get token from the Authorization header
  const authHeader = req.headers.authorization
  if (authHeader) {
    const token = authHeader.split(" ")[1]
    try {
      // Verify the JWT token
      const decoded = jwt.verify(
        token,
        process.env.JWT_SECRET || "fallback-secret-for-development-only",
      ) as jwt.JwtPayload

      // Validate user data against schema
      user = userSchema.parse({
        id: decoded.sub,
        email: decoded.email,
        name: decoded.name,
        role: decoded.role,
        isImpersonating: decoded.isImpersonating,
        originalUser: decoded.originalUser,
      })
    } catch (error) {
      console.error("Auth error:", error)
    }
  }

  return {
    req,
    res,
    user,
    prisma,
    session: user
      ? {
          user: {
            id: user.id,
            email: user.email,
            role: user.role,
          },
          id: user.id,
          lastRotated: Date.now(),
        }
      : null,
    previousData: undefined,
  }
}

type Context = Awaited<ReturnType<typeof createContext>>

const t = initTRPC.context<Context>().create()

export const router = t.router
export const procedure = t.procedure
export const middleware = t.middleware

// Create a middleware to check if user is authenticated
export const isAuthed = middleware(({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "You must be logged in",
    })
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  })
})

// Create a middleware to check if user is an admin
export const isAdmin = middleware(({ ctx, next }) => {
  if (!ctx.user) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "You must be logged in",
    })
  }

  if (ctx.user.role !== "admin") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Only administrators can access this resource",
    })
  }

  return next({
    ctx: {
      ...ctx,
      user: ctx.user,
    },
  })
})

// Protected procedures
export const authedProcedure = t.procedure.use(isAuthed)
export const adminProcedure = t.procedure.use(isAdmin)

// Export the trpc instance
export { t }

