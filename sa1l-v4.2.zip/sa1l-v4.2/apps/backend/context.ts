import type { CreateNextContextOptions } from "@trpc/server/adapters/next"
import { prisma } from "../../../archive13628-pm/apps/backend/db/prisma"

export async function createContext({ req, res }: CreateNextContextOptions) {
  // In production, use getServerSession from next-auth
  const session = {
    user: {
      id: "admin-id",
      email: "admin@western.ca",
      role: "admin",
    },
    id: "admin-id",
    lastRotated: 0,
  }

  // Add the user field to match the expected context type
  const user = session
    ? {
        id: session.user.id,
        email: session.user.email,
        role: session.user.role as "user" | "admin" | "faculty",
        name: undefined,
        isImpersonating: false,
      }
    : null

  return {
    prisma,
    session,
    user,
    req,
    res,
    previousData: undefined as any,
  }
}

export type Context = Awaited<ReturnType<typeof createContext>>

