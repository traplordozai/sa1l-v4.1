import { z } from "zod"

// Environment variable schema
const envSchema = z.object({
  // Server
  NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
  PORT: z
    .string()
    .transform((val) => (val ? Number(val) : 3000))
    .default("3000"),

  // Database
  DATABASE_URL: z.string().url(),

  // Redis
  REDIS_URL: z.string().url().default("redis://localhost:6379"),

  // Authentication
  JWT_SECRET: z.string().min(32),
  SESSION_SECRET: z.string().min(32),
  COOKIE_DOMAIN: z.string().optional(),

  // Email
  SMTP_HOST: z.string(),
  SMTP_PORT: z.string().transform((val) => (val ? Number(val) : undefined)),
  SMTP_USER: z.string(),
  SMTP_PASS: z.string(),
  SMTP_FROM: z.string().email(),
  SMTP_SECURE: z.string().transform((val) => val === "true"),

  // OpenAI
  OPENAI_API_KEY: z.string(),

  // Security
  CORS_ORIGINS: z.string().transform((val) => val.split(",")),
  RATE_LIMIT_WINDOW: z
    .string()
    .transform((val) => (val ? Number(val) : 900000))
    .default("900000"), // 15 minutes
  RATE_LIMIT_MAX: z
    .string()
    .transform((val) => (val ? Number(val) : 100))
    .default("100"),

  // Features
  ENABLE_DOCUMENT_ANALYSIS: z
    .string()
    .transform((val) => val === "true")
    .default("false"),
  ENABLE_PUSH_NOTIFICATIONS: z
    .string()
    .transform((val) => val === "true")
    .default("false"),
})

// Load and validate environment variables
function loadEnvConfig() {
  try {
    // In development, load .env file
    if (process.env.NODE_ENV !== "production") {
      require("dotenv").config()
    }

    const env = envSchema.parse(process.env)

    // Validate specific combinations
    if (env.NODE_ENV === "production") {
      const warnings: string[] = []

      if (!env.COOKIE_DOMAIN) {
        warnings.push(
          "COOKIE_DOMAIN is not set. This is recommended in production for proper cookie security and cross-domain functionality.",
        )
      }

      if (env.JWT_SECRET.length < 64) {
        warnings.push("JWT_SECRET should ideally be at least 64 characters in production")
      }

      if (warnings.length > 0) {
        console.warn("Production environment warnings:\n" + warnings.join("\n"))
      }
    }

    return env
  } catch (error) {
    console.error("Environment validation failed:")
    if (error instanceof z.ZodError) {
      error.errors.forEach((err) => {
        console.error(`- ${err.path.join(".")}: ${err.message}`)
      })
    } else if (error instanceof Error) {
      console.error(error.message)
    } else {
      console.error("An unknown error occurred during environment validation")
    }
    process.exit(1)
  }
}

// Export validated config
export const env = loadEnvConfig()

// Export type for usage in the application
export type Env = z.infer<typeof envSchema>

