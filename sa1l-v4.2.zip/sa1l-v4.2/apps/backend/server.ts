import { logger } from "./lib/logger"
import { scheduleLogRotation } from "./cron/log-rotation"
import { scheduleLogAnalytics } from "./services/log-analytics"

// Initialize logging system
export function initializeLoggingSystem() {
  logger.info("Initializing logging system")

  // Schedule log rotation
  scheduleLogRotation()

  // Schedule log analytics
  scheduleLogAnalytics()

  logger.info("Logging system initialized")
}

// Call this function during application startup
// In Next.js, you can add this to a custom server.js file
// or use it in a global middleware

