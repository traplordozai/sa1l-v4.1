import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "../../../../../../archive13628-pm/apps/backend/db/prisma"
import { verifyAuth } from "../../../utils/auth"

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    // Verify the user has admin permissions
    const authResult = await verifyAuth(req)
    if (!authResult.user?.isAdmin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Parse request body
    const body = await req.json()
    const { timeRange, dateRange } = body

    // Calculate the start date based on the time range
    let startDate = new Date()
    if (timeRange === "custom" && dateRange?.from) {
      startDate = new Date(dateRange.from)
    } else {
      const hours =
        timeRange === "1h"
          ? 1
          : timeRange === "6h"
            ? 6
            : timeRange === "24h"
              ? 24
              : timeRange === "7d"
                ? 24 * 7
                : timeRange === "30d"
                  ? 24 * 30
                  : 24 // Default to 24h

      startDate = new Date(Date.now() - hours * 60 * 60 * 1000)
    }

    // Set end date
    const endDate = timeRange === "custom" && dateRange?.to ? new Date(dateRange.to) : new Date()

    // Get total logs count
    const totalLogs = await prisma.errorLog.count({
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
      },
    })

    // Get counts by severity level
    const errorCount = await prisma.errorLog.count({
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
        severity: "error",
      },
    })

    const warnCount = await prisma.errorLog.count({
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
        severity: "warning",
      },
    })

    const infoCount = await prisma.errorLog.count({
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
        severity: "info",
      },
    })

    const httpCount = await prisma.errorLog.count({
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
        severity: "http",
      },
    })

    const debugCount = await prisma.errorLog.count({
      where: {
        timestamp: {
          gte: startDate,
          lte: endDate,
        },
        severity: "debug",
      },
    })

    // Get top errors
    const topErrors = await prisma.$queryRaw`
      SELECT message, COUNT(*) as count
      FROM "ErrorLog"
      WHERE timestamp >= ${startDate} AND timestamp <= ${endDate}
      AND severity = 'error'
      GROUP BY message
      ORDER BY count DESC
      LIMIT 5
    `

    // Get logs by hour
    const logsByHour = await prisma.$queryRaw`
      SELECT 
        EXTRACT(HOUR FROM timestamp) as hour,
        COUNT(*) as count
      FROM "ErrorLog"
      WHERE timestamp >= ${startDate} AND timestamp <= ${endDate}
      GROUP BY EXTRACT(HOUR FROM timestamp)
      ORDER BY hour
    `

    // Get logs by service
    const logsByService = await prisma.$queryRaw`
      SELECT 
        COALESCE(
          JSONB_EXTRACT_PATH_TEXT(context::jsonb, 'service'),
          'unknown'
        ) as service,
        COUNT(*) as count
      FROM "ErrorLog"
      WHERE timestamp >= ${startDate} AND timestamp <= ${endDate}
      GROUP BY service
      ORDER BY count DESC
      LIMIT 5
    `

    return NextResponse.json({
      totalLogs,
      errorCount,
      warnCount,
      infoCount,
      httpCount,
      debugCount,
      topErrors,
      logsByHour,
      logsByService,
    })
  } catch (error) {
    console.error("Error fetching log stats:", error)
    return NextResponse.json({ error: "Failed to fetch log statistics" }, { status: 500 })
  }
}

