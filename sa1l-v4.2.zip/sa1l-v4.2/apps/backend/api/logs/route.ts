import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "../../../../../archive13628-pm/apps/backend/db/prisma"
import { verifyAuth } from "../../utils/auth"

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    // Verify the user has admin permissions
    const authResult = await verifyAuth(req)
    if (!authResult.user?.isAdmin) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Parse request body
    const body = await req.json()
    const { timeRange, searchQuery, dateRange } = body

    // Calculate the start date based on the time range
    let startDate = new Date()
    if (timeRange === "custom" && dateRange?.from) {
      startDate = new Date(dateRange.from)
    } else {
      const hours =
        timeRange === "1h"
          ? 1
          : timeRange === "6h"
            ? 6
            : timeRange === "24h"
              ? 24
              : timeRange === "7d"
                ? 24 * 7
                : timeRange === "30d"
                  ? 24 * 30
                  : 24 // Default to 24h

      startDate = new Date(Date.now() - hours * 60 * 60 * 1000)
    }

    // Set end date
    const endDate = timeRange === "custom" && dateRange?.to ? new Date(dateRange.to) : new Date()

    // Build the query
    const whereClause: any = {
      timestamp: {
        gte: startDate,
        lte: endDate,
      },
    }

    // Add search query if provided
    if (searchQuery) {
      whereClause.OR = [
        { message: { contains: searchQuery, mode: "insensitive" } },
        { context: { contains: searchQuery, mode: "insensitive" } },
      ]
    }

    // Query the database
    const logs = await prisma.errorLog.findMany({
      where: whereClause,
      orderBy: {
        timestamp: "desc",
      },
      take: 100, // Limit to 100 results
    })

    return NextResponse.json(logs)
  } catch (error) {
    console.error("Error fetching logs:", error)
    return NextResponse.json({ error: "Failed to fetch logs" }, { status: 500 })
  }
}

