import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "../../../../../archive13628-pm/apps/backend/db/prisma"
import { verifyAuth } from "../../utils/auth"
import { logger } from "../../lib/logger"

/**
 * API route handler for logging client-side errors
 * @param req The incoming request
 * @returns NextResponse with the result
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    // Verify authentication (optional, depends on whether you want to require auth for error logging)
    const authResult = await verifyAuth(req)
    const userId = authResult.user?.id

    // Parse the request body
    const body = await req.json()
    const { message, stack, context, timestamp } = body

    // Validate required fields
    if (!message) {
      return NextResponse.json({ error: "Missing required field: message" }, { status: 400 })
    }

    // Create context for logging
    const logContext = {
      userId: userId || "anonymous",
      userAgent: req.headers.get("user-agent") || "unknown",
      ipAddress: req.headers.get("x-forwarded-for") || req.ip || "unknown",
      ...context,
    }

    // Log the error using our logger
    logger.error(message, { stack, ...logContext })

    // Log the error to the database
    await prisma.errorLog.create({
      data: {
        message,
        stack: stack || null,
        context: context ? JSON.stringify(context) : null,
        userId: userId || null,
        userAgent: req.headers.get("user-agent") || null,
        ipAddress: req.headers.get("x-forwarded-for") || req.ip || null,
        timestamp: timestamp ? new Date(timestamp) : new Date(),
        severity: context?.level || "error",
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error logging client error:", error)

    // Even if there's an error in our error logging, return success to the client
    // to avoid creating an error loop
    return NextResponse.json({ success: false, error: "Internal server error" }, { status: 500 })
  }
}

