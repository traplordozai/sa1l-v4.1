import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "../../../../../../archive13628-pm/apps/backend/db/prisma"
import { logger } from "../../../lib/logger"

export async function POST(req: NextRequest) {
  try {
    const {
      timeRange,
      searchQuery,
      dateRange,
      service,
      level,
      sortColumn = "timestamp",
      sortDirection = "desc",
      page = 1,
      pageSize = 25,
    } = await req.json()

    // Build the query
    const query: any = {}

    // Time range filter
    if (timeRange && timeRange !== "custom") {
      const now = new Date()
      let timeWindow: Date

      switch (timeRange) {
        case "1h":
          timeWindow = new Date(now.getTime() - 60 * 60 * 1000)
          break
        case "6h":
          timeWindow = new Date(now.getTime() - 6 * 60 * 60 * 1000)
          break
        case "24h":
          timeWindow = new Date(now.getTime() - 24 * 60 * 60 * 1000)
          break
        case "7d":
          timeWindow = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
          break
        case "30d":
          timeWindow = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
          break
      }

      if (timeWindow) {
        query.timestamp = {
          gte: timeWindow,
        }
      }
    } else if (dateRange) {
      // Custom date range
      query.timestamp = {
        gte: new Date(dateRange.from),
        lte: new Date(dateRange.to),
      }
    }

    // Service filter
    if (service && service !== "all") {
      query.service = service
    }

    // Level filter
    if (level && level !== "all") {
      query.level = level
    }

    // Search query
    if (searchQuery) {
      query.OR = [
        { message: { contains: searchQuery, mode: "insensitive" } },
        { service: { contains: searchQuery, mode: "insensitive" } },
        { userId: { contains: searchQuery, mode: "insensitive" } },
      ]
    }

    // Get total count
    const totalCount = await prisma.log.count({ where: query })

    // Get logs with pagination
    const logs = await prisma.log.findMany({
      where: query,
      orderBy: {
        [sortColumn]: sortDirection,
      },
      skip: (page - 1) * pageSize,
      take: pageSize,
    })

    return NextResponse.json({
      logs,
      pagination: {
        page,
        pageSize,
        totalCount,
        totalPages: Math.ceil(totalCount / pageSize),
      },
    })
  } catch (error) {
    logger.error("Error fetching logs", { error })
    return NextResponse.json({ error: "Failed to fetch logs" }, { status: 500 })
  }
}

