import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "../../../../../../../archive13628-pm/apps/backend/db/prisma"
import { logger } from "../../../../lib/logger"
import { LogAnalyticsService } from "../../../../../../../archive13628-pm/apps/backend/services/log-analytics"

export async function POST(req: NextRequest) {
  try {
    const { timeRange, dateRange, anomalyThreshold = 2.0 } = await req.json()

    // Calculate time window
    let timeWindow: Date
    const now = new Date()

    if (timeRange && timeRange !== "custom") {
      switch (timeRange) {
        case "1h":
          timeWindow = new Date(now.getTime() - 60 * 60 * 1000)
          break
        case "6h":
          timeWindow = new Date(now.getTime() - 6 * 60 * 60 * 1000)
          break
        case "24h":
          timeWindow = new Date(now.getTime() - 24 * 60 * 60 * 1000)
          break
        case "7d":
          timeWindow = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
          break
        case "30d":
          timeWindow = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
          break
        default:
          timeWindow = new Date(now.getTime() - 24 * 60 * 60 * 1000)
      }
    } else if (dateRange) {
      // Custom date range
      timeWindow = new Date(dateRange.from)
    } else {
      // Default to 24 hours
      timeWindow = new Date(now.getTime() - 24 * 60 * 60 * 1000)
    }

    // Get log counts by level
    const logCounts = await prisma.log.groupBy({
      by: ["level"],
      _count: {
        id: true,
      },
      where: {
        timestamp: {
          gte: timeWindow,
        },
      },
    })

    // Calculate total logs
    const totalLogs = logCounts.reduce((sum, item) => sum + item._count.id, 0)

    // Get top errors
    const topErrors = await prisma.log.groupBy({
      by: ["message"],
      _count: {
        id: true,
      },
      where: {
        level: "error",
        timestamp: {
          gte: timeWindow,
        },
      },
      orderBy: {
        _count: {
          id: "desc",
        },
      },
      take: 5,
    })

    // Get logs by hour
    const logsByHour = await prisma.$queryRaw`
      SELECT 
        date_trunc('hour', "timestamp") as hour,
        count(*) as count
      FROM "Log"
      WHERE "timestamp" >= ${timeWindow}
      GROUP BY date_trunc('hour', "timestamp")
      ORDER BY hour
    `

    // Get logs by service
    const logsByService = await prisma.log.groupBy({
      by: ["service"],
      _count: {
        id: true,
      },
      where: {
        timestamp: {
          gte: timeWindow,
        },
        service: {
          not: null,
        },
      },
      orderBy: {
        _count: {
          id: "desc",
        },
      },
    })

    // Get performance metrics
    const performanceMetrics = await prisma.$queryRaw`
      SELECT 
        AVG(CAST(context->>'responseTime' as FLOAT)) as avg_response_time,
        PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY CAST(context->>'responseTime' as FLOAT)) as p95_response_time,
        PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY CAST(context->>'responseTime' as FLOAT)) as p99_response_time,
        COUNT(CASE WHEN CAST(context->>'status' as INTEGER) >= 400 THEN 1 END) * 100.0 / COUNT(*) as error_rate
      FROM "Log"
      WHERE 
        "timestamp" >= ${timeWindow}
        AND context->>'responseTime' IS NOT NULL
    `

    // Get anomalies
    const anomalies = await LogAnalyticsService.detectAnomalies(
      (now.getTime() - timeWindow.getTime()) / (60 * 60 * 1000), // Time window in hours
      anomalyThreshold,
    )

    // Format the response
    const stats = {
      totalLogs,
      errorCount: logCounts.find((item) => item.level === "error")?._count.id || 0,
      warnCount: logCounts.find((item) => item.level === "warn")?._count.id || 0,
      infoCount: logCounts.find((item) => item.level === "info")?._count.id || 0,
      httpCount: logCounts.find((item) => item.level === "http")?._count.id || 0,
      debugCount: logCounts.find((item) => item.level === "debug")?._count.id || 0,
      topErrors: topErrors.map((item) => ({
        message: item.message,
        count: item._count.id,
      })),
      logsByHour: logsByHour.map((item: any) => ({
        hour: new Date(item.hour).toISOString(),
        count: Number.parseInt(item.count),
      })),
      logsByService: logsByService.map((item) => ({
        service: item.service || "unknown",
        count: item._count.id,
      })),
      performanceMetrics: {
        avgResponseTime: performanceMetrics[0]?.avg_response_time || 0,
        p95ResponseTime: performanceMetrics[0]?.p95_response_time || 0,
        p99ResponseTime: performanceMetrics[0]?.p99_response_time || 0,
        errorRate: performanceMetrics[0]?.error_rate || 0,
        successRate: 100 - (performanceMetrics[0]?.error_rate || 0),
      },
      anomalies,
    }

    return NextResponse.json(stats)
  } catch (error) {
    logger.error("Error fetching log stats", { error })
    return NextResponse.json({ error: "Failed to fetch log stats" }, { status: 500 })
  }
}

