import * as Sentry from "@sentry/nextjs"
import winston from "winston"

// Custom Sentry transport for Winston
export class SentryTransport extends winston.Transport {
  constructor(opts?: winston.transport.TransportStreamOptions) {
    super(opts)
    this.level = opts?.level || "error"
  }

  log(info: any, callback: () => void) {
    const { level, message, ...meta } = info

    // Only send errors and warnings to Sentry
    if (level === "error" || level === "warn") {
      // Create a new Sentry event
      Sentry.withScope((scope) => {
        // Add all metadata as extra context
        if (meta) {
          Object.keys(meta).forEach((key) => {
            scope.setExtra(key, meta[key])
          })
        }

        // Set the log level
        scope.setLevel(level === "error" ? Sentry.Severity.Error : Sentry.Severity.Warning)

        // If there's an error object, capture it as an exception
        if (meta.error instanceof Error) {
          Sentry.captureException(meta.error)
        } else {
          // Otherwise capture as a message
          Sentry.captureMessage(message)
        }
      })
    }

    callback()
  }
}

