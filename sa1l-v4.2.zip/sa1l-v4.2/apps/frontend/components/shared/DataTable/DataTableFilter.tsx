"use client"

import { useState } from "react"
import { X, Filter } from "lucide-react"
import type { Column } from "./index"

interface DataTableFilterProps<T> {
  columns: Column<T>[]
  filters: Record<string, any>
  onFilterChange: (columnId: string, value: any) => void
  onClearFilters: () => void
}

/**
 * Filter component for DataTable
 */
export default function DataTableFilter<T>({
  columns,
  filters,
  onFilterChange,
  onClearFilters,
}: DataTableFilterProps<T>) {
  const [isOpen, setIsOpen] = useState(false)
  const activeFilterCount = Object.keys(filters).filter(
    (key) => filters[key] !== undefined && filters[key] !== null && filters[key] !== "",
  ).length

  return (
    <div className="relative">
      <div className="flex items-center space-x-2">
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className={`inline-flex items-center rounded-md border px-3 py-2 text-sm font-medium shadow-sm focus:outline-none focus:ring-2 focus:ring-westernPurple focus:ring-offset-2 ${
            activeFilterCount > 0
              ? "border-westernPurple bg-westernPurple text-white hover:bg-westernPurple-dark"
              : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50"
          }`}
        >
          <Filter className="-ml-0.5 mr-2 h-4 w-4" aria-hidden="true" />
          Filters
          {activeFilterCount > 0 && (
            <span className="ml-2 inline-flex h-5 w-5 items-center justify-center rounded-full bg-white text-xs font-medium text-westernPurple">
              {activeFilterCount}
            </span>
          )}
        </button>

        {activeFilterCount > 0 && (
          <button
            type="button"
            onClick={onClearFilters}
            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-westernPurple focus:ring-offset-2"
          >
            <X className="-ml-0.5 mr-2 h-4 w-4" aria-hidden="true" />
            Clear filters
          </button>
        )}
      </div>

      {isOpen && (
        <div className="absolute left-0 z-10 mt-2 w-96 origin-top-left rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="p-4">
            <h3 className="text-lg font-medium leading-6 text-gray-900">Filters</h3>
            <div className="mt-4 space-y-4">
              {columns.map((column) => (
                <div key={column.id} className="space-y-2">
                  <label htmlFor={`filter-${column.id}`} className="block text-sm font-medium text-gray-700">
                    {column.header}
                  </label>
                  <input
                    type="text"
                    id={`filter-${column.id}`}
                    value={filters[column.id] || ""}
                    onChange={(e) => onFilterChange(column.id, e.target.value)}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-westernPurple focus:ring-westernPurple sm:text-sm"
                    placeholder={`Filter by ${column.header.toLowerCase()}`}
                  />
                </div>
              ))}
            </div>
            <div className="mt-5 flex justify-end">
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-westernPurple focus:ring-offset-2"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

