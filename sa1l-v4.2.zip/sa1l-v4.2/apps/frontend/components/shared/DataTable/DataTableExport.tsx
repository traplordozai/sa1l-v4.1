"use client"

import { useState } from "react"
import { Download, FileText, FileSpreadsheet, FileIcon as FilePdf } from "lucide-react"

interface DataTableExportProps {
  onExport: (format: "csv" | "excel" | "pdf") => void
}

/**
 * Component for exporting data from DataTable
 */
export default function DataTableExport({ onExport }: DataTableExportProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleExport = (format: "csv" | "excel" | "pdf") => {
    onExport(format)
    setIsOpen(false)
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-westernPurple focus:ring-offset-2"
      >
        <Download className="-ml-0.5 mr-2 h-4 w-4" aria-hidden="true" />
        Export
      </button>

      {isOpen && (
        <div className="absolute right-0 z-10 mt-2 w-48 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="py-1">
            <button
              onClick={() => handleExport("csv")}
              className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileText className="mr-3 h-5 w-5 text-gray-400" aria-hidden="true" />
              Export as CSV
            </button>
            <button
              onClick={() => handleExport("excel")}
              className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FileSpreadsheet className="mr-3 h-5 w-5 text-gray-400" aria-hidden="true" />
              Export as Excel
            </button>
            <button
              onClick={() => handleExport("pdf")}
              className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
            >
              <FilePdf className="mr-3 h-5 w-5 text-gray-400" aria-hidden="true" />
              Export as PDF
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

