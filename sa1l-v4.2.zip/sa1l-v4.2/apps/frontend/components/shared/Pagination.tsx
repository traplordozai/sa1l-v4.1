"use client"

import { useMemo } from "react"
import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react"

interface PaginationProps {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
  className?: string
  showPageNumbers?: boolean
  showFirstLastButtons?: boolean
  maxVisiblePages?: number
}

/**
 * Pagination component for navigating through multiple pages of content
 */
export default function Pagination({
  currentPage,
  totalPages,
  onPageChange,
  className = "",
  showPageNumbers = true,
  showFirstLastButtons = true,
  maxVisiblePages = 5,
}: PaginationProps) {
  // Calculate which page numbers to show
  const pageNumbers = useMemo(() => {
    if (!showPageNumbers || totalPages <= 1) return []
    if (totalPages <= maxVisiblePages) {
      return Array.from({ length: totalPages }, (_, i) => i + 1)
    }

    // Complex pagination with ellipsis
    const pages: (number | "ellipsis")[] = []

    // Always show first page
    pages.push(1)

    // Calculate start and end of the middle section
    let startPage = Math.max(2, currentPage - Math.floor(maxVisiblePages / 2))
    const endPage = Math.min(totalPages - 1, startPage + maxVisiblePages - 3)

    // Adjust if we're near the end
    if (endPage === totalPages - 1) {
      startPage = Math.max(2, endPage - (maxVisiblePages - 3))
    }

    // Add ellipsis before middle section if needed
    if (startPage > 2) {
      pages.push("ellipsis")
    }

    // Add middle section
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i)
    }

    // Add ellipsis after middle section if needed
    if (endPage < totalPages - 1) {
      pages.push("ellipsis")
    }

    // Always show last page
    pages.push(totalPages)

    return pages
  }, [currentPage, totalPages, showPageNumbers, maxVisiblePages])

  // Don't render pagination if there's only one page
  if (totalPages <= 1) return null

  return (
    <nav className={`flex items-center justify-center space-x-1 ${className}`} aria-label="Pagination">
      {/* Previous page button */}
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className={`relative inline-flex items-center rounded-md px-2 py-2 text-sm font-medium ${
          currentPage === 1 ? "cursor-not-allowed text-gray-300" : "text-gray-700 hover:bg-gray-50"
        }`}
        aria-label="Previous page"
      >
        <ChevronLeft className="h-5 w-5" aria-hidden="true" />
      </button>

      {/* First page button */}
      {showFirstLastButtons && currentPage > 3 && (
        <button
          onClick={() => onPageChange(1)}
          className="relative inline-flex items-center rounded-md px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
          aria-label="First page"
        >
          First
        </button>
      )}

      {/* Page numbers */}
      {showPageNumbers &&
        pageNumbers.map((page, index) =>
          page === "ellipsis" ? (
            <span
              key={`ellipsis-${index}`}
              className="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700"
            >
              <MoreHorizontal className="h-5 w-5" aria-hidden="true" />
            </span>
          ) : (
            <button
              key={page}
              onClick={() => onPageChange(page)}
              className={`relative inline-flex items-center rounded-md px-4 py-2 text-sm font-medium ${
                page === currentPage ? "bg-westernPurple text-white" : "text-gray-700 hover:bg-gray-50"
              }`}
              aria-current={page === currentPage ? "page" : undefined}
              aria-label={`Page ${page}`}
            >
              {page}
            </button>
          ),
        )}

      {/* Last page button */}
      {showFirstLastButtons && currentPage < totalPages - 2 && (
        <button
          onClick={() => onPageChange(totalPages)}
          className="relative inline-flex items-center rounded-md px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
          aria-label="Last page"
        >
          Last
        </button>
      )}

      {/* Next page button */}
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className={`relative inline-flex items-center rounded-md px-2 py-2 text-sm font-medium ${
          currentPage === totalPages ? "cursor-not-allowed text-gray-300" : "text-gray-700 hover:bg-gray-50"
        }`}
        aria-label="Next page"
      >
        <ChevronRight className="h-5 w-5" aria-hidden="true" />
      </button>
    </nav>
  )
}

