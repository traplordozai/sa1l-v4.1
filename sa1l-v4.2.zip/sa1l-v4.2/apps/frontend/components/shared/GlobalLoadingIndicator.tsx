"use client"

import { useEffect, useState } from "react"
import { usePathname, useSearchParams } from "next/navigation"

/**
 * Global loading indicator that shows during page navigation
 * This component should be placed in the root layout
 */
export default function GlobalLoadingIndicator() {
  const [isLoading, setIsLoading] = useState(false)
  const pathname = usePathname()
  const searchParams = useSearchParams()

  useEffect(() => {
    // Create a timeout to avoid flashing the loading indicator for fast navigations
    let timeout: NodeJS.Timeout

    const handleStart = () => {
      timeout = setTimeout(() => setIsLoading(true), 100)
    }

    const handleComplete = () => {
      clearTimeout(timeout)
      setIsLoading(false)
    }

    // Add event listeners for router events
    window.addEventListener("beforeunload", handleStart)
    document.addEventListener("page-transition-start", handleStart)
    document.addEventListener("page-transition-complete", handleComplete)

    return () => {
      clearTimeout(timeout)
      window.removeEventListener("beforeunload", handleStart)
      document.removeEventListener("page-transition-start", handleStart)
      document.removeEventListener("page-transition-complete", handleComplete)
    }
  }, [])

  // Reset loading state when the route changes
  useEffect(() => {
    setIsLoading(false)
  }, [pathname, searchParams])

  if (!isLoading) return null

  return (
    <div className="fixed top-0 left-0 right-0 z-50 h-1 bg-gradient-to-r from-westernPurple to-westernBlue">
      <div className="h-full w-full animate-pulse bg-white opacity-30"></div>
    </div>
  )
}

