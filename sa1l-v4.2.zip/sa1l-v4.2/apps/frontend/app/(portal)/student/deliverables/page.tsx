import AdminLayout from "@/components/features/admin/AdminLayout"

export default function StudentDeliverables() {
  return (
    <AdminLayout>
      <h1 className="text-2xl font-bold">📤 Deliverables</h1>
      <p className="text-white mt-2">Coming soon: Student deliverables features.</p>
    </AdminLayout>
  )
}

