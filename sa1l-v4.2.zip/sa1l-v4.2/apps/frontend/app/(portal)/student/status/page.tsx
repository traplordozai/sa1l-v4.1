export default function StatusPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Status Page</h1>
      <p>Work in progress...</p>
    </div>
  )
}

