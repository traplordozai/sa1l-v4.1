"use client"

import { trpc } from "@/utils/trpc"
import AdminLayout from "@/components/features/admin/AdminLayout"
import { useToast } from "@/components/ui/Toast.tsx"

export default function AdminLogsPage() {
  const { Toast } = useToast()
  const { data: logs, isLoading, error } = trpc.log.getAll.useQuery()

  return (
    <AdminLayout>
      <Toast />
      <h1 className="text-3xl font-bold mb-4">📝 System Logs</h1>
      {isLoading && (
        <div className="animate-spin border-t-2 border-white border-solid h-6 w-6 rounded-full mx-auto my-4" />
      )}
      {error && <p className="text-red-500">Error loading logs</p>}

      <ul className="space-y-2">
        {logs?.map((log) => (
          <li key={log.id} className="p-3 bg-deepFocus text-white rounded">
            <span className="font-mono text-sm">[{log.level}]</span> {log.message}
          </li>
        ))}
      </ul>
    </AdminLayout>
  )
}

