import { Suspense } from "react"
import LogDashboard from "@/components/admin/LogDashboard"
import { Skeleton } from "@/components/ui/skeleton"

export const metadata = {
  title: "Logs Dashboard | Admin",
  description: "Monitor and analyze application logs",
}

export default function LogsPage() {
  return (
    <div className="container mx-auto py-6">
      <Suspense fallback={<LogDashboardSkeleton />}>
        <LogDashboard />
      </Suspense>
    </div>
  )
}

function LogDashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Skeleton className="h-10 w-64" />
        <div className="flex gap-2">
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>

      <div className="flex flex-col md:flex-row gap-4">
        <Skeleton className="h-80 w-full" />
        <Skeleton className="h-80 w-full" />
      </div>

      <Skeleton className="h-96 w-full" />
      <Skeleton className="h-80 w-full" />
    </div>
  )
}

