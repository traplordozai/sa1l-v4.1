import { createNextApiHandler } from "@trpc/server/adapters/next"
import { createContext } from "../../../../backend/context"
import { appRouter } from "../../../../backend/server"

// This file is a Next.js API route handler for tRPC
// For Vite, you may need a different approach to expose your tRPC API
// (like using express or fastify on the backend)
export default createNextApiHandler({
  router: appRouter,
  createContext,
})

