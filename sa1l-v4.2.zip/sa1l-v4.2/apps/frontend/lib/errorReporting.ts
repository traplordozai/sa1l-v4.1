/**
 * Error reporting utility functions
 * This module provides functions for capturing and reporting errors to monitoring services
 */

import { logger } from "../../backend/lib/logger"

interface ErrorContext {
  extra?: Record<string, any>
  tags?: Record<string, string>
  user?: {
    id?: string
    email?: string
    username?: string
  }
  level?: "fatal" | "error" | "warning" | "info" | "debug"
}

// Client-side error reporting
export async function reportError(error: Error, context: Record<string, any> = {}) {
  try {
    // Log the error locally
    console.error("Error:", error.message, error.stack)

    // Send to server for logging
    await fetch("/api/log/error", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: error.message,
        stack: error.stack,
        context,
        timestamp: new Date().toISOString(),
      }),
    })
  } catch (reportingError) {
    // Fallback logging if reporting fails
    console.error("Failed to report error:", reportingError)
  }
}

// Server-side error logging
export function logServerError(error: Error, context: Record<string, any> = {}) {
  const contextLogger = logger.child({ ...context })
  contextLogger.error(error.message, { stack: error.stack })
}

/**
 * Captures an exception and sends it to the error monitoring service
 * @param error The error object to capture
 * @param context Additional context information about the error
 */
export function captureException(error: Error, context?: ErrorContext): void {
  // In a production environment, this would send the error to a service like Sentry
  console.error("Error captured:", error)

  if (context) {
    console.error("Error context:", JSON.stringify(context, null, 2))
  }

  // Example implementation with Sentry
  // if (typeof window !== 'undefined' && window.Sentry) {
  //   if (context?.user) {
  //     window.Sentry.setUser(context.user);
  //   }
  //
  //   if (context?.tags) {
  //     window.Sentry.setTags(context.tags);
  //   }
  //
  //   if (context?.extra) {
  //     window.Sentry.setExtras(context.extra);
  //   }
  //
  //   window.Sentry.captureException(error);
  // }

  // Log to server-side error tracking in production
  if (process.env.NODE_ENV === "production") {
    fetch("/api/log/error", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message: error.message,
        stack: error.stack,
        context,
        timestamp: new Date().toISOString(),
      }),
      // Use keepalive to ensure the request completes even if the page is unloading
      keepalive: true,
    }).catch(console.error) // Catch and log any errors with the logging itself
  }
}

/**
 * Captures a message and sends it to the error monitoring service
 * @param message The message to capture
 * @param context Additional context information about the message
 */
export function captureMessage(message: string, context?: ErrorContext): void {
  // In a production environment, this would send the message to a service like Sentry
  const level = context?.level || "info"
  console.log(`[${level}] ${message}`)

  if (context) {
    console.log("Message context:", JSON.stringify(context, null, 2))
  }

  // Example implementation with Sentry
  // if (typeof window !== 'undefined' && window.Sentry) {
  //   if (context?.user) {
  //     window.Sentry.setUser(context.user);
  //   }
  //
  //   if (context?.tags) {
  //     window.Sentry.setTags(context.tags);
  //   }
  //
  //   if (context?.extra) {
  //     window.Sentry.setExtras(context.extra);
  //   }
  //
  //   window.Sentry.captureMessage(message, context?.level || 'info');
  // }

  // Log to server-side in production
  if (process.env.NODE_ENV === "production" && level !== "debug") {
    fetch("/api/log/message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message,
        level,
        context,
        timestamp: new Date().toISOString(),
      }),
      // Use keepalive to ensure the request completes even if the page is unloading
      keepalive: true,
    }).catch(console.error) // Catch and log any errors with the logging itself
  }
}

/**
 * Initializes the error reporting service
 * @param config Configuration options for the error reporting service
 */
export function initErrorReporting(config?: {
  dsn?: string
  environment?: string
  release?: string
}): void {
  // Example implementation with Sentry
  // if (typeof window !== 'undefined' && window.Sentry) {
  //   window.Sentry.init({
  //     dsn: config?.dsn || process.env.NEXT_PUBLIC_SENTRY_DSN,
  //     environment: config?.environment || process.env.NEXT_PUBLIC_ENVIRONMENT || 'development',
  //     release: config?.release || process.env.NEXT_PUBLIC_VERSION || '1.0.0',
  //     tracesSampleRate: 1.0,
  //   });
  // }

  // Set up global error handlers
  if (typeof window !== "undefined") {
    // Handle unhandled promise rejections
    window.addEventListener("unhandledrejection", (event) => {
      captureException(event.reason instanceof Error ? event.reason : new Error(String(event.reason)), {
        tags: { mechanism: "unhandledrejection" },
      })
    })

    // Override the console.error method to capture errors
    const originalConsoleError = console.error
    console.error = (...args) => {
      // Call the original console.error
      originalConsoleError.apply(console, args)

      // Capture the first argument if it's an Error
      const firstArg = args[0]
      if (firstArg instanceof Error) {
        captureException(firstArg, { tags: { mechanism: "console.error" } })
      }
    }
  }
}

